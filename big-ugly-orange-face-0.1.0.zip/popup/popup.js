"use strict";
(() => {
  // src/shared/blocked-subjects.ts
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { enabled: false, keywords: [...defaultTrumpKeywords] };
    }
    const candidate = value;
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      enabled: candidate.enabled === true,
      keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
    };
  }
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }

  // src/popup/popup.ts
  var TITLE = "Big Ugly Orange Face";
  var START_ERROR = "Subject settings are unavailable.";
  function createTextElement(tagName, className, text) {
    const element = document.createElement(tagName);
    element.className = className;
    element.textContent = text;
    return element;
  }
  async function mountPopup(root, chromeApi) {
    root.replaceChildren();
    document.title = TITLE;
    const heading = createTextElement("h1", "popup-title", TITLE);
    const subjects = createTextElement("div", "popup-subjects", "");
    const subjectsTitle = createTextElement("span", "popup-subjects-title", "Subject frosting");
    const subjectsState = createTextElement("span", "popup-subjects-state", "");
    const subjectsDescription = createTextElement("span", "popup-subjects-description", "");
    subjects.append(subjectsTitle, subjectsState, subjectsDescription);
    const error = createTextElement("p", "popup-error", "");
    error.setAttribute("role", "alert");
    error.hidden = true;
    const settings = createTextElement("button", "popup-settings", "Open settings");
    settings.type = "button";
    settings.addEventListener("click", () => void chromeApi.runtime.openOptionsPage());
    root.append(heading, subjects, error, settings);
    try {
      const values = await chromeApi.storage.local.get("blocked-subjects");
      const config = parseBlockedSubjects(values["blocked-subjects"]);
      subjectsState.textContent = config.enabled ? "On" : "Off";
      subjectsDescription.textContent = config.enabled ? "Frosting likely matches everywhere." : "Turn on subject frosting in Settings.";
    } catch {
      error.textContent = START_ERROR;
      error.hidden = false;
    }
  }
  var popupRoot = document.querySelector("#app");
  if (popupRoot && typeof chrome !== "undefined") {
    void mountPopup(popupRoot, {
      storage: { local: { get: (key) => chrome.storage.local.get(key) } },
      runtime: { openOptionsPage: () => chrome.runtime.openOptionsPage() }
    });
  }
})();
//# sourceMappingURL=popup.js.map
