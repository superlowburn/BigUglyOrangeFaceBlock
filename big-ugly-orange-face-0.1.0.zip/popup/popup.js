"use strict";
(() => {
  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { enabled: false, keywords: [...defaultTrumpKeywords] };
    }
    const candidate = value;
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      enabled: candidate.enabled === true,
      keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
    };
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }

  // src/popup/popup.ts
  var TITLE = "Big Ugly Orange Face";
  var START_ERROR = "Subject settings are unavailable.";
  function createTextElement(tagName, className, text) {
    const element = document.createElement(tagName);
    element.className = className;
    element.textContent = text;
    return element;
  }
  async function mountPopup(root, chromeApi) {
    root.replaceChildren();
    document.title = TITLE;
    const header = createTextElement("header", "popup-header", "");
    const logo = document.createElement("img");
    logo.className = "popup-logo";
    logo.src = "../icons/icon.svg";
    logo.alt = "";
    const headerCopy = createTextElement("div", "popup-header-copy", "");
    const heading = createTextElement("h1", "popup-title", TITLE);
    const tagline = createTextElement("p", "popup-tagline", "Keep the Orange One out of sight.");
    headerCopy.append(heading, tagline);
    header.append(logo, headerCopy);
    const subjects = createTextElement("section", "popup-subjects", "");
    const subjectHeader = createTextElement("div", "popup-subject-header", "");
    const subjectsTitle = createTextElement("h2", "popup-subjects-title", "Donald Trump");
    const switchLabel = createTextElement("label", "popup-switch-label", "");
    const subjectsState = createTextElement("span", "popup-subjects-state", "");
    const subjectSwitch = document.createElement("input");
    subjectSwitch.className = "popup-switch";
    subjectSwitch.type = "checkbox";
    subjectSwitch.setAttribute("role", "switch");
    subjectSwitch.setAttribute("aria-label", "Frost pictures of Donald Trump");
    subjectSwitch.disabled = true;
    switchLabel.append(subjectsState, subjectSwitch);
    subjectHeader.append(subjectsTitle, switchLabel);
    const subjectsDescription = createTextElement("p", "popup-subjects-description", "");
    subjects.append(subjectHeader, subjectsDescription);
    const error = createTextElement("p", "popup-error", "");
    error.setAttribute("role", "alert");
    error.hidden = true;
    const settings = createTextElement("button", "popup-settings", "Edit matching words & settings");
    settings.type = "button";
    settings.addEventListener("click", () => void chromeApi.runtime.openOptionsPage());
    const privacy = createTextElement(
      "p",
      "popup-privacy",
      "Works locally. Your images never leave this device."
    );
    root.append(header, subjects, error, settings, privacy);
    try {
      const store = new BlockedSubjectsStore(chromeApi.storage.local);
      let config = await store.get();
      renderSubjectState(config, subjectSwitch, subjectsState, subjectsDescription);
      subjectSwitch.disabled = false;
      subjectSwitch.addEventListener("change", () => {
        const next = { ...config, enabled: subjectSwitch.checked };
        void store.set(next).then(() => {
          config = next;
          error.hidden = true;
          renderSubjectState(config, subjectSwitch, subjectsState, subjectsDescription);
        }).catch(() => {
          renderSubjectState(config, subjectSwitch, subjectsState, subjectsDescription);
          error.textContent = START_ERROR;
          error.hidden = false;
        });
      });
    } catch {
      error.textContent = START_ERROR;
      error.hidden = false;
    }
  }
  function renderSubjectState(config, subjectSwitch, state, description) {
    subjectSwitch.checked = config.enabled;
    state.textContent = config.enabled ? "On" : "Off";
    description.textContent = config.enabled ? "Likely pictures of Donald Trump are frosted on every site." : "Pictures of Donald Trump are currently visible.";
  }
  var popupRoot = document.querySelector("#app");
  if (popupRoot && typeof chrome !== "undefined") {
    void mountPopup(popupRoot, {
      storage: {
        local: {
          get: (key) => chrome.storage.local.get(key),
          set: (items) => chrome.storage.local.set(items)
        }
      },
      runtime: { openOptionsPage: () => chrome.runtime.openOptionsPage() }
    });
  }
})();
//# sourceMappingURL=popup.js.map
