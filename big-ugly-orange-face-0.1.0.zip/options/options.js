"use strict";
(() => {
  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { enabled: false, keywords: [...defaultTrumpKeywords] };
    }
    const candidate = value;
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      enabled: candidate.enabled === true,
      keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
    };
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }

  // src/options/options.ts
  async function mountOptions(root, chromeApi) {
    document.title = "Big Ugly Orange Face Settings";
    const values = await chromeApi.storage.local.get("blocked-subjects");
    const blockedStore = new BlockedSubjectsStore(chromeApi.storage.local);
    const blocked = parseBlockedSubjects(values["blocked-subjects"]);
    const enabled = root.querySelector("#blocked-subjects-enabled");
    const keywords = root.querySelector("#blocked-subject-keywords");
    const status = root.querySelector("#blocked-subjects-status");
    if (enabled) enabled.checked = blocked.enabled;
    if (keywords) keywords.value = blocked.keywords.join("\n");
    const save = () => {
      const config = parseBlockedSubjects({
        enabled: enabled?.checked ?? false,
        keywords: uniqueKeywords(keywords?.value.split("\n") ?? [])
      });
      if (keywords) keywords.value = config.keywords.join("\n");
      void blockedStore.set(config).then(() => {
        if (status) status.textContent = "Saved locally";
      });
    };
    enabled?.addEventListener("change", save);
    keywords?.addEventListener("change", save);
  }
  if (typeof chrome !== "undefined" && typeof document !== "undefined") {
    const root = document.querySelector("#app");
    if (root) void mountOptions(root, chrome);
  }
})();
//# sourceMappingURL=options.js.map
