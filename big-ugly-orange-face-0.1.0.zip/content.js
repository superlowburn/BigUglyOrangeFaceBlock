"use strict";
(() => {
  // src/media/provider-frames.ts
  var supportedProviders = [
    { host: "www.youtube.com", path: /^\/embed\/[^/]+$/ },
    { host: "www.youtube-nocookie.com", path: /^\/embed\/[^/]+$/ },
    { host: "player.vimeo.com", path: /^\/video\/[^/]+$/ }
  ];
  function isSupportedVideoFrame(element) {
    if (!(element instanceof HTMLIFrameElement)) return false;
    const source = element.getAttribute("src");
    if (!source) return false;
    try {
      return supportedProviderUrl(element.src, document.baseURI) !== null;
    } catch {
      return false;
    }
  }
  function supportedProviderUrl(source, base = "https://invalid.local/") {
    try {
      const url = new URL(source, base);
      return url.protocol === "https:" && supportedProviders.some(
        ({ host, path }) => url.hostname === host && path.test(url.pathname)
      ) ? url : null;
    } catch {
      return null;
    }
  }
  var ProviderFrameController = class {
    constructor(authorization = runtimeAuthorization(), environment = browserFrameEnvironment()) {
      this.authorization = authorization;
      this.environment = environment;
    }
    authorization;
    environment;
    states = /* @__PURE__ */ new WeakMap();
    activeFrames = /* @__PURE__ */ new Set();
    gate(frame) {
      const existing = this.states.get(frame);
      if (existing) {
        existing.version += 1;
        void this.revoke(existing);
        delete existing.authorizedSource;
        existing.ready = this.environment.prepare(frame);
        return;
      }
      if (!isSupportedVideoFrame(frame)) return;
      const originalSource = frame.getAttribute("src");
      if (!originalSource) return;
      const state = { originalSource, version: 0, pendingSourceChanges: 0 };
      this.states.set(frame, state);
      this.activeFrames.add(frame);
      state.ready = this.environment.prepare(frame);
    }
    async release(frame) {
      const state = this.states.get(frame);
      if (!state) return;
      await this.loadAuthorized(frame, state, true);
    }
    regate(frame) {
      const state = this.states.get(frame);
      if (!state) return;
      state.version += 1;
      void this.revoke(state);
      delete state.authorizedSource;
      state.ready = this.environment.prepare(frame);
    }
    async restore(frame) {
      const state = this.states.get(frame);
      if (!state) return;
      await this.loadAuthorized(frame, state, false);
    }
    async trust(frame, sourceChanges = 0) {
      let state = this.states.get(frame);
      const originalSource = frame.getAttribute("src");
      if (!originalSource) return;
      const ownSourceChanges = state ? Math.min(sourceChanges, state.pendingSourceChanges) : 0;
      if (state) state.pendingSourceChanges -= ownSourceChanges;
      const pageSourceChanged = sourceChanges > ownSourceChanges;
      if (state && (originalSource === "about:blank" || originalSource === state.authorizedSource && !pageSourceChanged)) {
        await state.inflight;
        return;
      }
      if (!isSupportedVideoFrame(frame)) return;
      if (state?.originalSource === originalSource && state.inflight) {
        await state.inflight;
        return;
      }
      if (state) {
        const operation = this.reloadTrusted(frame, state, originalSource);
        state.inflight = operation;
        try {
          await operation;
        } finally {
          if (state.inflight === operation) delete state.inflight;
        }
        return;
      }
      state = { originalSource, version: 0, pendingSourceChanges: 0 };
      this.states.set(frame, state);
      this.activeFrames.add(frame);
      state.ready = this.environment.prepare(frame);
      await state.ready;
      if (this.states.get(frame) !== state) return;
      await this.loadAuthorized(frame, state, false);
    }
    async reloadTrusted(frame, previous, originalSource) {
      previous.version += 1;
      await this.revoke(previous);
      if (this.states.get(frame) !== previous) return;
      const state = { originalSource, version: 0, pendingSourceChanges: 0 };
      this.states.set(frame, state);
      state.ready = this.environment.prepare(frame);
      await state.ready;
      if (this.states.get(frame) !== state) return;
      await this.loadAuthorized(frame, state, false);
    }
    forget(frame) {
      const state = this.states.get(frame);
      if (!state) return;
      state.version += 1;
      void this.revoke(state);
      this.states.delete(frame);
      this.activeFrames.delete(frame);
    }
    dispose() {
      for (const frame of [...this.activeFrames]) this.forget(frame);
    }
    async loadAuthorized(frame, state, disableAutoplay) {
      if (state.inflight) return state.inflight;
      const operation = this.performAuthorizedNavigation(frame, state, disableAutoplay);
      state.inflight = operation;
      try {
        await operation;
      } finally {
        if (state.inflight === operation) delete state.inflight;
      }
    }
    async performAuthorizedNavigation(frame, state, disableAutoplay) {
      const version = ++state.version;
      await state.ready;
      if (state.version !== version || this.states.get(frame) !== state) return;
      await this.revoke(state);
      const authorization = await this.authorization.authorize(
        state.originalSource,
        disableAutoplay
      );
      if (state.version !== version || this.states.get(frame) !== state) {
        await this.authorization.revoke(authorization.grantId);
        return;
      }
      state.grantId = authorization.grantId;
      state.authorizedSource = authorization.source;
      state.pendingSourceChanges += 1;
      try {
        this.environment.navigate(frame, authorization.source);
      } catch (error) {
        state.pendingSourceChanges -= 1;
        await this.revoke(state);
        throw error;
      }
    }
    async revoke(state) {
      const grantId = state.grantId;
      if (grantId === void 0) return;
      delete state.grantId;
      await this.authorization.revoke(grantId);
    }
  };
  function browserFrameEnvironment() {
    return {
      prepare: async (frame) => {
        frame.removeAttribute("srcdoc");
        frame.setAttribute("src", "about:blank");
      },
      navigate: (frame, source) => {
        frame.setAttribute("src", source);
      }
    };
  }
  function runtimeAuthorization() {
    return {
      authorize: async (source, disableAutoplay) => {
        const response = await chrome.runtime.sendMessage({
          type: "provider:authorize",
          source,
          disableAutoplay
        });
        if (!response || typeof response !== "object" || !("grantId" in response) || typeof response.grantId !== "number" || !("source" in response) || typeof response.source !== "string") {
          throw new TypeError("Provider authorization failed");
        }
        return { grantId: response.grantId, source: response.source };
      },
      revoke: async (grantId) => {
        await chrome.runtime.sendMessage({ type: "provider:revoke", grantId });
      }
    };
  }

  // src/media/classifier.ts
  var imageMinimum = 48;
  var undecoratedImageMinimum = 96;
  var videoMinimum = 96;
  var interactiveDescendant = "button, a, input, select, textarea, [role=button], [tabindex]";
  function classifyElement(element, env) {
    if (!(element instanceof HTMLElement)) return null;
    const { width, height } = env.box(element);
    if (width <= 0 || height <= 0) return null;
    if (element instanceof HTMLVideoElement) {
      return hasEitherDimension(width, height, videoMinimum) ? { element, kind: "native-video" } : null;
    }
    if (isSupportedVideoFrame(element)) {
      return hasEitherDimension(width, height, videoMinimum) ? { element, kind: "video-iframe" } : null;
    }
    if (element instanceof HTMLInputElement && element.type.toLowerCase() === "image") {
      return hasBothDimensions(width, height, imageMinimum) ? { element, kind: "image" } : null;
    }
    if (element instanceof HTMLImageElement) {
      if (!hasBothDimensions(width, height, imageMinimum)) return null;
      const alt = element.getAttribute("alt")?.trim() ?? "";
      if (!alt && hasMeaningfulOverlappingCopy(element, env)) return null;
      if (alt || hasBothDimensions(width, height, undecoratedImageMinimum)) {
        return { element, kind: "image" };
      }
      return null;
    }
    if (hasBothDimensions(width, height, undecoratedImageMinimum) && env.style(element).backgroundImage.includes("url(") && !hasRenderedText(element, env) && !element.querySelector(interactiveDescendant)) {
      return { element, kind: "background-image" };
    }
    return null;
  }
  function hasMeaningfulOverlappingCopy(element, env) {
    const parent = element.parentElement;
    if (!parent) return false;
    const box = env.box(element);
    const redditLightbox = element.closest("#shreddit-media-lightbox");
    const container = redditLightbox ?? parent;
    const source = element.currentSrc || element.src;
    for (const sibling of container.querySelectorAll("img[alt]")) {
      if (sibling === element || !(sibling instanceof HTMLImageElement) || !sibling.getAttribute("alt")?.trim() || !redditLightbox && (sibling.currentSrc || sibling.src) !== source) {
        continue;
      }
      if (substantiallyOverlaps(box, env.box(sibling), redditLightbox ? 0.25 : 0.5)) return true;
    }
    return false;
  }
  function substantiallyOverlaps(first, second, minimumSizeRatio) {
    if (first.left === void 0 || first.top === void 0 || first.right === void 0 || first.bottom === void 0 || second.left === void 0 || second.top === void 0 || second.right === void 0 || second.bottom === void 0) {
      return false;
    }
    const intersectionWidth = Math.max(
      0,
      Math.min(first.right, second.right) - Math.max(first.left, second.left)
    );
    const intersectionHeight = Math.max(
      0,
      Math.min(first.bottom, second.bottom) - Math.max(first.top, second.top)
    );
    const smallerArea = Math.min(first.width * first.height, second.width * second.height);
    const largerArea = Math.max(first.width * first.height, second.width * second.height);
    if (smallerArea <= 0 || smallerArea / largerArea < minimumSizeRatio) return false;
    return intersectionWidth * intersectionHeight / smallerArea >= 0.8;
  }
  function hasRenderedText(element, env) {
    const walker = element.ownerDocument.createTreeWalker(element, NodeFilter.SHOW_TEXT);
    let node = walker.nextNode();
    while (node) {
      if (node.textContent?.trim() && node.parentElement && isRendered(node.parentElement, element, env)) {
        return true;
      }
      node = walker.nextNode();
    }
    return false;
  }
  function isRendered(textHost, boundary, env) {
    let current = textHost;
    while (current) {
      const style2 = env.style(current);
      if (current.hidden || style2.display === "none" || style2.visibility === "hidden" || style2.visibility === "collapse" || style2.opacity === "0") {
        return false;
      }
      if (current === boundary) break;
      current = current.parentElement;
    }
    const style = env.style(textHost);
    const box = env.box(textHost);
    const clipped = style.position === "absolute" && box.width <= 1 && box.height <= 1 && style.overflow === "hidden" && (style.clip && style.clip !== "auto" || style.clipPath && style.clipPath !== "none");
    return !clipped;
  }
  function hasBothDimensions(width, height, minimum) {
    return width >= minimum && height >= minimum;
  }
  function hasEitherDimension(width, height, minimum) {
    return width >= minimum || height >= minimum;
  }

  // src/media/description.ts
  var fallbackDescriptions = {
    image: "Image frosted by Big Ugly Orange Face",
    "background-image": "Background image frosted by Big Ugly Orange Face",
    "native-video": "Video frosted by Big Ugly Orange Face",
    "video-iframe": "Embedded video frosted by Big Ugly Orange Face"
  };
  function resolveDescription(candidate) {
    const { element, kind } = candidate;
    const description = normalize(element.getAttribute("alt")) || labelledBy(element) || normalize(element.getAttribute("aria-label")) || figureCaption(element) || normalize(element.getAttribute("title")) || fallbackDescriptions[kind];
    return Array.from(description).slice(0, 500).join("").trim();
  }
  function labelledBy(element) {
    const ids = element.getAttribute("aria-labelledby")?.split(/\s+/u).filter(Boolean) ?? [];
    const root = element.getRootNode();
    return normalize(ids.map((id) => {
      if (root instanceof Document || root instanceof ShadowRoot) {
        return root.getElementById(id)?.textContent ?? "";
      }
      return "";
    }).filter(Boolean).join(" "));
  }
  function figureCaption(element) {
    const figure = element.closest("figure");
    return normalize(figure?.querySelector(":scope > figcaption")?.textContent ?? null);
  }
  function normalize(value) {
    return value?.replace(/\s+/gu, " ").trim() ?? "";
  }

  // src/media/native-video.ts
  var NativeVideoController = class {
    states = /* @__PURE__ */ new WeakMap();
    trustedActivation;
    constructor(environment = {}) {
      this.trustedActivation = environment.trustedActivation ?? ((event) => event.isTrusted);
    }
    secure(video) {
      if (this.states.has(video)) return;
      let state;
      const onPlay = () => {
        if (!state.released || !state.playbackAllowed) this.enforce(video);
      };
      const onPointerDown = (event) => {
        if (!state.released || !this.trustedActivation(event)) return;
        if (event.composedPath().includes(video)) state.playbackAllowed = true;
      };
      const onKeyDown = (event) => {
        if (state.released && event.target === video && (event.key === "Enter" || event.key === " ") && this.trustedActivation(event)) {
          state.playbackAllowed = true;
        }
      };
      state = {
        hadOwnPlay: Object.prototype.hasOwnProperty.call(video, "play"),
        originalPlay: video.play,
        originallyMuted: video.muted,
        released: false,
        playbackAllowed: false,
        onPlay,
        onPointerDown,
        onKeyDown
      };
      this.states.set(video, state);
      video.play = () => {
        if (!state.released || !state.playbackAllowed) {
          this.enforce(video);
          return Promise.resolve();
        }
        return state.originalPlay.call(video);
      };
      video.addEventListener("play", onPlay);
      video.addEventListener("playing", onPlay);
      video.ownerDocument.addEventListener("pointerdown", onPointerDown, true);
      video.addEventListener("keydown", onKeyDown, true);
      this.enforce(video);
    }
    release(video) {
      const state = this.states.get(video);
      if (!state) return;
      state.released = true;
      state.playbackAllowed = false;
    }
    reprotect(video) {
      const state = this.states.get(video);
      if (!state) return;
      state.released = false;
      state.playbackAllowed = false;
      this.enforce(video);
    }
    restore(video) {
      const state = this.states.get(video);
      if (!state) return;
      video.removeEventListener("play", state.onPlay);
      video.removeEventListener("playing", state.onPlay);
      video.ownerDocument.removeEventListener("pointerdown", state.onPointerDown, true);
      video.removeEventListener("keydown", state.onKeyDown, true);
      if (state.hadOwnPlay) video.play = state.originalPlay;
      else Reflect.deleteProperty(video, "play");
      video.muted = state.originallyMuted;
      this.states.delete(video);
    }
    enforce(video) {
      video.pause();
      video.muted = true;
    }
  };

  // src/protection/styles.ts
  var protectionStyles = `
:host {
  all: initial;
}

*,
*::before,
*::after {
  box-sizing: border-box;
}

.buof-layer {
  border: 0;
  padding: 0;
  color: inherit;
  background: transparent;
  text-align: initial;
  position: absolute;
  z-index: 2147483647;
  overflow: hidden;
  pointer-events: auto;
  cursor: default;
  font: 14px/1.35 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.buof-frost {
  backdrop-filter: blur(var(--buof-frost-blur, 25px));
  background: rgba(211, 211, 211, 0.10);
}

.buof-reveal-surface {
  position: absolute;
  inset: 0;
  z-index: 1;
  width: 100%;
  height: 100%;
  padding: 0;
  border: 0;
  background: transparent;
  cursor: pointer;
}

.buof-show-cue {
  position: absolute;
  left: 50%;
  bottom: 12px;
  padding: 5px 9px;
  color: #fff;
  border-radius: 999px;
  background: rgba(31, 33, 35, 0.82);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.16);
  opacity: 0;
  transform: translateX(-50%);
  transition: opacity 120ms ease;
  pointer-events: none;
  font: 600 12px/1 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.buof-reveal-surface:hover .buof-show-cue,
.buof-reveal-surface:focus-visible .buof-show-cue {
  opacity: 1;
}

.buof-compact .buof-show-cue {
  bottom: 6px;
  padding: 4px 7px;
  font-size: 11px;
}

.buof-info-control {
  position: absolute;
  left: var(--buof-caption-left, 12px);
  bottom: var(--buof-caption-bottom, 12px);
  z-index: 3;
  width: calc(100% - var(--buof-caption-left, 12px) - var(--buof-control-right, 12px));
  min-height: var(--buof-info-size, 28px);
  pointer-events: none;
}

.buof-info-control[hidden] {
  display: none;
}

.buof-info-button {
  appearance: none;
  display: grid;
  width: var(--buof-info-size, 28px);
  height: var(--buof-info-size, 28px);
  padding: 0;
  place-items: center;
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.52);
  border-radius: 50%;
  background: rgba(31, 33, 35, 0.78);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.16);
  font: 700 17px/1 Georgia, serif;
  pointer-events: auto;
  backdrop-filter: blur(8px);
  cursor: pointer;
}

.buof-info-button:hover {
  background: rgba(31, 33, 35, 0.92);
}

.buof-info-preview,
.buof-info-panel {
  position: absolute;
  bottom: calc(var(--buof-info-size, 28px) + 6px);
  left: 0;
  display: none;
  width: min(320px, 100%);
  color: #fff;
  background: rgba(31, 33, 35, 0.94);
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 8px;
  box-shadow: 0 6px 18px rgba(0, 0, 0, 0.22);
  backdrop-filter: blur(10px);
  pointer-events: auto;
}

.buof-info-preview {
  padding: 7px 9px;
  font-size: 12px;
  line-height: 1.35;
}

.buof-info-control:hover:not(.buof-info-pinned) .buof-info-preview,
.buof-info-button:focus-visible + .buof-info-preview {
  display: block;
}

.buof-info-control.buof-info-pinned .buof-info-preview {
  display: none;
}

.buof-info-pinned .buof-info-panel {
  display: grid;
}

.buof-info-description {
  max-height: 120px;
  padding: 9px 10px;
  overflow: auto;
  font-size: 13px;
  line-height: 1.4;
}

.buof-info-always {
  min-height: 36px;
  padding: 8px 10px;
  color: #e4e7e9;
  border: 0;
  border-top: 1px solid rgba(255, 255, 255, 0.14);
  border-radius: 0 0 7px 7px;
  text-align: left;
  background: transparent;
  cursor: pointer;
  font: 600 12px/1.25 -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
}

.buof-info-always:hover {
  color: #fff;
  background: rgba(255, 255, 255, 0.10);
}

.buof-reprotect {
  appearance: none;
  display: grid;
  width: var(--buof-control-size, 44px);
  height: var(--buof-control-size, 44px);
  padding: 10px;
  place-items: center;
  color: #fff;
  border: 1px solid rgba(255, 255, 255, 0.26);
  background: rgba(31, 33, 35, 0.78);
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.17);
  backdrop-filter: blur(8px);
  cursor: pointer;
  font: inherit;
}

.buof-reprotect {
  border-radius: 50%;
}

.buof-reprotect:hover {
  background: rgba(31, 33, 35, 0.90);
}

.buof-reprotect svg {
  display: block;
  overflow: visible;
  fill: none;
  stroke: currentColor;
  stroke-width: 1.8;
  stroke-linecap: round;
  stroke-linejoin: round;
}

.buof-reprotect svg {
  width: 28px;
  height: 28px;
}

.buof-compact .buof-reprotect {
  padding: 5px;
}

.buof-compact .buof-reprotect svg {
  width: 22px;
  height: 22px;
}

.buof-compact .buof-info-control {
  --buof-info-size: 24px;
}

.buof-compact .buof-info-button {
  font-size: 15px;
}

.buof-compact .buof-info-preview,
.buof-compact .buof-info-description {
  font-size: 11px;
}

.buof-reveal-surface:focus-visible,
.buof-info-button:focus-visible,
.buof-info-always:focus-visible,
.buof-reprotect:focus-visible {
  outline: 2px solid #fff;
  outline-offset: 2px;
  box-shadow: 0 0 0 4px rgba(31, 33, 35, 0.72);
}

.buof-layer.buof-revealed {
  overflow: visible;
  pointer-events: none;
  cursor: default;
}

.buof-reprotect {
  width: 100%;
  height: 100%;
  opacity: 0.78;
  pointer-events: auto;
  transition: opacity 120ms ease, background-color 120ms ease;
}

.buof-target-hover .buof-reprotect,
.buof-reprotect:focus-visible {
  opacity: 1;
}

@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    scroll-behavior: auto !important;
    transition: none !important;
    animation: none !important;
  }
}
`;

  // src/protection/renderer.ts
  function isTrustedActivation(event) {
    if (!event.isTrusted) return false;
    if (event.type === "click") return true;
    if (event.type !== "keydown") return false;
    const key = event.key;
    return key === "Enter" || key === " " || key === "Spacebar";
  }
  var ProtectionRenderer = class {
    document;
    window;
    requestFrame;
    cancelFrame;
    trustedActivation;
    records = /* @__PURE__ */ new Map();
    dirtyRecords = /* @__PURE__ */ new Set();
    frame = null;
    listening = false;
    constructor(environment = {}) {
      this.document = environment.document ?? document;
      this.window = environment.window ?? window;
      this.requestFrame = environment.requestAnimationFrame ?? this.window.requestAnimationFrame.bind(this.window);
      this.cancelFrame = environment.cancelAnimationFrame ?? this.window.cancelAnimationFrame.bind(this.window);
      this.trustedActivation = environment.trustedActivation ?? isTrustedActivation;
    }
    protect(candidate, options) {
      const existing = this.records.get(candidate.element);
      if (existing && !existing.removed) return existing.handle;
      const { host, shadow } = this.createRoot(candidate.element);
      const layer = this.document.createElement("div");
      layer.className = "buof-layer";
      shadow.append(layer);
      let record;
      const handle = {
        reveal: () => this.reveal(record),
        reprotect: () => this.reprotect(record),
        remove: () => this.remove(record),
        update: () => this.scheduleRecordUpdate(record),
        setDescriptionVisible: (visible) => this.setRecordDescriptionVisible(record, visible),
        isRevealed: () => record.revealed
      };
      record = {
        candidate,
        description: options.description,
        host,
        layer,
        onReveal: options.onReveal,
        onToggleDescriptions: options.onToggleDescriptions,
        onReprotect: options.onReprotect,
        descriptionVisible: options.descriptionsVisible,
        pageDescriptionsVisible: options.descriptionsVisible,
        revealed: false,
        removed: false,
        handle,
        onMouseEnter: () => layer.classList.add("buof-target-hover"),
        onMouseLeave: () => layer.classList.remove("buof-target-hover")
      };
      candidate.element.addEventListener("mouseenter", record.onMouseEnter);
      candidate.element.addEventListener("mouseleave", record.onMouseLeave);
      this.records.set(candidate.element, record);
      markProtected(candidate);
      const box = candidate.element.getBoundingClientRect();
      this.renderProtected(record, box);
      this.updateRecord(record, box);
      this.startListening();
      return handle;
    }
    debugLayerFor(element) {
      return this.records.get(element)?.layer ?? null;
    }
    createRoot(target) {
      const { host, shadow } = this.createIsolatedHost();
      const anchor = target.closest(
        "a[href], button, input, select, textarea, summary, [role=button], [role=link], [tabindex], [contenteditable]:not([contenteditable=false])"
      ) ?? target.closest("picture") ?? target;
      anchor.parentNode?.insertBefore(host, anchor.nextSibling);
      if (!host.isConnected) this.document.documentElement.append(host);
      showInTopLayer(host);
      return { host, shadow };
    }
    createIsolatedHost() {
      const host = this.document.createElement("div");
      host.setAttribute("data-buof-root", "");
      host.setAttribute("popover", "manual");
      Object.assign(host.style, {
        position: "absolute",
        left: "0",
        top: "0",
        width: "100vw",
        height: "100vh",
        margin: "0",
        padding: "0",
        border: "0",
        overflow: "visible",
        zIndex: "2147483647",
        pointerEvents: "none"
      });
      const shadow = host.attachShadow({ mode: "open" });
      const style = this.document.createElement("style");
      style.textContent = protectionStyles;
      shadow.append(style);
      return { host, shadow };
    }
    activate(record, event, action) {
      if (!this.trustedActivation(event) || record.removed) return false;
      event.preventDefault();
      event.stopPropagation();
      if (action === "reprotect") record.handle.reprotect();
      else record.handle.reveal();
      return true;
    }
    reveal(record) {
      if (record.removed || record.revealed) return;
      const keepFocus = record.layer.getRootNode().activeElement === record.layer.querySelector(".buof-reveal-surface");
      record.revealed = true;
      record.layer.className = "buof-layer buof-revealed";
      const reprotect = this.createIconButton("buof-reprotect", "Frost again", "undo");
      reprotect.addEventListener("click", (event) => this.activate(record, event, "reprotect"));
      record.layer.replaceChildren(reprotect);
      if (keepFocus) reprotect.focus();
      record.candidate.element.removeAttribute("data-buof-protected");
      record.onReveal();
      this.updateRecord(record);
    }
    reprotect(record) {
      if (record.removed || !record.revealed) return;
      const keepFocus = record.layer.getRootNode().activeElement === record.layer.querySelector(".buof-reprotect");
      record.revealed = false;
      this.renderProtected(record);
      if (keepFocus) record.layer.querySelector(".buof-reveal-surface")?.focus();
      this.updateRecord(record);
      markProtected(record.candidate);
      record.onReprotect();
    }
    renderProtected(record, box) {
      const { layer, description } = record;
      layer.className = "buof-layer buof-frost";
      layer.removeAttribute("aria-label");
      const presentation = presentationFor(box ?? record.candidate.element.getBoundingClientRect());
      const compact = presentation.compact;
      layer.classList.toggle("buof-compact", compact);
      const revealSurface = this.createButton(
        "",
        "buof-reveal-surface",
        `${optionsLabel(record)}: ${description}`
      );
      const showCue = this.document.createElement("span");
      showCue.className = "buof-show-cue";
      showCue.setAttribute("aria-hidden", "true");
      showCue.textContent = "Show";
      revealSurface.append(showCue);
      revealSurface.addEventListener("click", (event) => {
        this.activate(record, event, "reveal");
      });
      const children = [revealSurface];
      const infoControl = this.document.createElement("div");
      infoControl.className = "buof-info-control";
      infoControl.hidden = !presentation.showInfo;
      const info = this.createButton("i", "buof-info-button", "Show description");
      info.setAttribute("aria-expanded", "false");
      info.setAttribute("aria-controls", "buof-info-panel");
      const characters = Array.from(description);
      const preview = characters.length > 50 ? `${characters.slice(0, 50).join("")}\u2026` : description;
      const previewCopy = this.document.createElement("div");
      previewCopy.className = "buof-info-preview";
      previewCopy.textContent = preview;
      const panel = this.document.createElement("div");
      panel.id = "buof-info-panel";
      panel.className = "buof-info-panel";
      const fullCopy = this.document.createElement("div");
      fullCopy.className = "buof-info-description";
      fullCopy.textContent = description;
      const always = this.createButton(
        "Show descriptions by default on this site",
        "buof-info-always",
        "Show descriptions by default on this site"
      );
      info.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        record.descriptionVisible = !record.descriptionVisible;
        this.updateDescriptionState(record);
      });
      always.addEventListener("click", (event) => {
        if (!this.trustedActivation(event)) return;
        event.preventDefault();
        event.stopPropagation();
        record.onToggleDescriptions();
      });
      infoControl.addEventListener("keydown", (event) => {
        if (event.key !== "Escape" || !record.descriptionVisible) return;
        event.preventDefault();
        record.descriptionVisible = false;
        this.updateDescriptionState(record);
        info.focus();
      });
      panel.append(fullCopy, always);
      infoControl.append(info, previewCopy, panel);
      children.push(infoControl);
      layer.replaceChildren(...children);
      this.updateDescriptionState(record);
    }
    createButton(text, className, label) {
      const button = this.document.createElement("button");
      button.type = "button";
      button.className = className;
      button.textContent = text;
      button.setAttribute("aria-label", label);
      button.addEventListener("mousedown", (event) => event.preventDefault());
      return button;
    }
    createIconButton(className, label, icon) {
      const button = this.createButton("", className, label);
      const svg = this.document.createElementNS("http://www.w3.org/2000/svg", "svg");
      svg.setAttribute("viewBox", "0 0 24 24");
      svg.setAttribute("aria-hidden", "true");
      svg.innerHTML = '<path d="M7 7H3V3M3.5 7A8 8 0 1 1 5 16"/>';
      button.append(svg);
      return button;
    }
    updateDescriptionState(record) {
      const control = record.layer.querySelector(".buof-info-control");
      const info = record.layer.querySelector(".buof-info-button");
      const always = record.layer.querySelector(".buof-info-always");
      control?.classList.toggle("buof-info-pinned", record.descriptionVisible);
      info?.setAttribute("aria-expanded", String(record.descriptionVisible));
      info?.setAttribute("aria-label", record.descriptionVisible ? "Hide description" : "Show description");
      if (always) {
        always.textContent = record.pageDescriptionsVisible ? "Stop showing descriptions by default" : "Show descriptions by default on this site";
        always.setAttribute("aria-label", always.textContent);
      }
    }
    setRecordDescriptionVisible(record, visible) {
      record.descriptionVisible = visible;
      record.pageDescriptionsVisible = visible;
      this.updateDescriptionState(record);
    }
    isCompact(record, currentBox) {
      const box = currentBox ?? record.candidate.element.getBoundingClientRect();
      return presentationFor(box).compact;
    }
    updateRecord(record, currentBox) {
      if (record.removed) return;
      const box = currentBox ?? record.candidate.element.getBoundingClientRect();
      const presentation = presentationFor(box);
      const { compact, controlSize, inset, blur, showInfo } = presentation;
      record.layer.style.setProperty("--buof-control-size", `${controlSize}px`);
      record.layer.style.setProperty("--buof-control-inset", `${inset}px`);
      record.layer.style.setProperty("--buof-frost-blur", `${blur}px`);
      const infoControl = record.layer.querySelector(".buof-info-control");
      if (infoControl) infoControl.hidden = !showInfo;
      if (record.revealed) {
        const width = Math.min(controlSize, box.width);
        const height = Math.min(controlSize, box.height);
        const visibleRight = Math.min(box.right, this.window.innerWidth);
        const topInset2 = topEdgeOcclusionInset(
          this.document,
          record.candidate.element,
          record.layer,
          box,
          this.window
        );
        const visibleTop = Math.max(box.top + topInset2, 0);
        Object.assign(record.layer.style, {
          left: `${this.window.scrollX + Math.max(box.left, visibleRight - width - inset)}px`,
          top: `${this.window.scrollY + Math.max(box.top, Math.min(box.bottom - height, visibleTop + inset))}px`,
          width: `${width}px`,
          height: `${height}px`
        });
        return;
      }
      if (!record.revealed && layerCompact(record.layer) !== compact) {
        this.renderProtected(record, box);
      }
      const topInset = topEdgeOcclusionInset(
        this.document,
        record.candidate.element,
        record.layer,
        box,
        this.window
      );
      const clippedTop = box.top + topInset;
      Object.assign(record.layer.style, {
        left: `${this.window.scrollX + box.left}px`,
        top: `${this.window.scrollY + clippedTop}px`,
        width: `${box.width}px`,
        height: `${Math.max(0, box.height - topInset)}px`
      });
      record.layer.style.setProperty("--buof-control-right", `${Math.max(inset, box.right - this.window.innerWidth + inset)}px`);
      record.layer.style.setProperty("--buof-control-top", `${Math.max(inset, inset - clippedTop)}px`);
      record.layer.style.setProperty("--buof-caption-left", `${Math.max(inset, inset - box.left)}px`);
      record.layer.style.setProperty("--buof-caption-bottom", `${inset}px`);
      record.layer.classList.toggle("buof-compact", compact);
      const coveredByIframe = isCoveredByIframe(
        this.document,
        record.candidate.element,
        record.layer,
        box,
        this.window
      );
      record.layer.style.pointerEvents = coveredByIframe ? "none" : "";
      record.layer.style.visibility = coveredByIframe ? "hidden" : "";
    }
    scheduleRecordUpdate(record) {
      if (record.removed) return;
      this.dirtyRecords.add(record);
      this.scheduleFrame();
    }
    scheduleAllUpdates = () => {
      for (const record of this.records.values()) this.dirtyRecords.add(record);
      this.scheduleFrame();
    };
    scheduleFrame() {
      if (this.frame !== null) return;
      this.frame = this.requestFrame(() => {
        this.frame = null;
        const records = [...this.dirtyRecords];
        this.dirtyRecords.clear();
        for (const record of records) this.updateRecord(record);
      });
    }
    startListening() {
      if (this.listening) return;
      this.window.addEventListener("scroll", this.scheduleAllUpdates, true);
      this.window.addEventListener("resize", this.scheduleAllUpdates);
      this.listening = true;
    }
    remove(record) {
      if (record.removed) return;
      record.removed = true;
      this.dirtyRecords.delete(record);
      record.host.remove();
      record.candidate.element.removeAttribute("data-buof-protected");
      record.candidate.element.removeEventListener("mouseenter", record.onMouseEnter);
      record.candidate.element.removeEventListener("mouseleave", record.onMouseLeave);
      if (this.records.get(record.candidate.element) === record) this.records.delete(record.candidate.element);
      this.stopListeningIfIdle();
    }
    stopListeningIfIdle() {
      if (this.records.size > 0) return;
      this.window.removeEventListener("scroll", this.scheduleAllUpdates, true);
      this.window.removeEventListener("resize", this.scheduleAllUpdates);
      this.listening = false;
      if (this.frame !== null) this.cancelFrame(this.frame);
      this.frame = null;
    }
  };
  function topEdgeOcclusionInset(document2, target, layer, box, window2) {
    if (typeof document2.elementFromPoint !== "function") return 0;
    const visibleLeft = Math.max(0, box.left);
    const visibleRight = Math.min(window2.innerWidth, box.right);
    const visibleTop = Math.max(0, box.top);
    const visibleBottom = Math.min(window2.innerHeight, box.bottom);
    if (visibleLeft >= visibleRight || visibleTop >= visibleBottom) return 0;
    const priorPointerEvents = layer.style.pointerEvents;
    let underlying = null;
    try {
      layer.style.pointerEvents = "none";
      underlying = deepElementFromPoint(
        document2,
        (visibleLeft + visibleRight) / 2,
        Math.min(visibleBottom - 1, visibleTop + 1)
      );
    } finally {
      layer.style.pointerEvents = priorPointerEvents;
    }
    let current = underlying instanceof HTMLElement ? underlying : underlying?.parentElement ?? null;
    while (current && current !== document2.documentElement) {
      if (!isExtensionElement(current) && current !== target && !current.contains(target) && !target.contains(current)) {
        const position = window2.getComputedStyle(current).position;
        if (position === "fixed" || position === "sticky") {
          const occluder = current.getBoundingClientRect();
          if (occluder.left <= visibleLeft + 1 && occluder.right >= visibleRight - 1 && occluder.top <= visibleTop + 1 && occluder.bottom > visibleTop + 1 && occluder.height <= 120 && occluder.height < window2.innerHeight - 1) {
            return Math.min(box.height, Math.max(0, occluder.bottom - box.top));
          }
        }
      }
      current = composedParent(current);
    }
    return 0;
  }
  function deepElementFromPoint(document2, x, y) {
    let current = document2.elementFromPoint(x, y);
    while (current?.shadowRoot) {
      const shadow = current.shadowRoot;
      const nested = shadow.elementFromPoint?.(x, y) ?? null;
      if (!nested || nested === current) break;
      current = nested;
    }
    return current;
  }
  function composedParent(element) {
    if (element.parentElement) return element.parentElement;
    const root = element.getRootNode();
    return root instanceof ShadowRoot && root.host instanceof HTMLElement ? root.host : null;
  }
  function isExtensionElement(element) {
    if (element.closest("[data-buof-root]")) return true;
    const root = element.getRootNode();
    return root instanceof ShadowRoot && root.host instanceof HTMLElement && root.host.hasAttribute("data-buof-root");
  }
  function mediaLabel(kind) {
    return kind === "native-video" || kind === "video-iframe" ? "video" : "image";
  }
  function optionsLabel(_record) {
    return "Reveal blocked subject";
  }
  function layerCompact(layer) {
    return layer.classList.contains("buof-compact");
  }
  function presentationFor(box) {
    const shortEdge = Math.min(box.width, box.height);
    const showInfo = box.width >= 520 && box.height >= 320;
    if (box.width < 280 || box.height < 180) {
      return { compact: true, controlSize: 30, inset: 6, blur: 12, showInfo };
    }
    if (shortEdge < 360) {
      return { compact: false, controlSize: 36, inset: 8, blur: 18, showInfo };
    }
    return { compact: false, controlSize: 44, inset: 12, blur: 25, showInfo };
  }
  function markProtected(candidate) {
    candidate.element.setAttribute(
      "data-buof-protected",
      mediaLabel(candidate.kind)
    );
  }
  function showInTopLayer(host) {
    if (typeof host.showPopover !== "function") {
      host.removeAttribute("popover");
      return;
    }
    try {
      host.showPopover();
    } catch {
      host.removeAttribute("popover");
    }
  }
  function isCoveredByIframe(document2, target, layer, box, window2) {
    if (typeof document2.elementFromPoint !== "function") return false;
    const visibleLeft = Math.max(0, box.left);
    const visibleRight = Math.min(window2.innerWidth, box.right);
    const visibleTop = Math.max(0, box.top);
    const visibleBottom = Math.min(window2.innerHeight, box.bottom);
    if (visibleLeft >= visibleRight || visibleTop >= visibleBottom) return false;
    const priorPointerEvents = layer.style.pointerEvents;
    layer.style.pointerEvents = "none";
    const underlying = document2.elementFromPoint(
      (visibleLeft + visibleRight) / 2,
      (visibleTop + visibleBottom) / 2
    );
    layer.style.pointerEvents = priorPointerEvents;
    if (underlying === target || underlying?.tagName !== "IFRAME") return false;
    const iframeBox = underlying.getBoundingClientRect();
    return iframeBox.left <= visibleLeft && iframeBox.right >= visibleRight && iframeBox.top <= visibleTop && iframeBox.bottom >= visibleBottom;
  }

  // src/shared/blocked-subjects.ts
  var blockedSubjectsKey = "blocked-subjects";
  var defaultTrumpKeywords = [
    "Donald Trump",
    "Donald J. Trump",
    "President Trump",
    "Former President Trump",
    "Trump",
    "@realDonaldTrump",
    "The Donald"
  ];
  function parseBlockedSubjects(value) {
    if (!value || typeof value !== "object") {
      return { enabled: false, keywords: [...defaultTrumpKeywords] };
    }
    const candidate = value;
    const keywords = Array.isArray(candidate.keywords) ? uniqueKeywords(candidate.keywords.filter((item) => typeof item === "string")) : [];
    return {
      enabled: candidate.enabled === true,
      keywords: keywords.length > 0 ? keywords : [...defaultTrumpKeywords]
    };
  }
  function matchesBlockedSubject(element, keywords) {
    return textMatchesBlockedSubject(subjectContext(element), keywords);
  }
  function candidateMatchesBlockedSubject(candidate, config) {
    return config.enabled && isSubjectCandidate(candidate) && (matchesBlockedSubject(candidate.element, config.keywords) || candidate.kind === "background-image" && textMatchesBlockedSubject(
      candidate.element.ownerDocument.defaultView?.getComputedStyle(candidate.element).backgroundImage ?? "",
      config.keywords
    ));
  }
  var BlockedSubjectsStore = class {
    constructor(area, onChanged) {
      this.area = area;
      this.onChanged = onChanged;
    }
    area;
    onChanged;
    async get() {
      return parseBlockedSubjects((await this.area.get(blockedSubjectsKey))[blockedSubjectsKey]);
    }
    async set(config) {
      await this.area.set({ [blockedSubjectsKey]: parseBlockedSubjects(config) });
    }
    watch(listener) {
      const onChange = (changes, area) => {
        if (area === "local" && blockedSubjectsKey in changes) {
          listener(parseBlockedSubjects(changes[blockedSubjectsKey]?.newValue));
        }
      };
      this.onChanged?.addListener(onChange);
      return () => this.onChanged?.removeListener(onChange);
    }
  };
  function uniqueKeywords(keywords) {
    const seen = /* @__PURE__ */ new Set();
    return keywords.flatMap((keyword) => {
      const normalized = keyword.replace(/\s+/gu, " ").trim();
      const key = normalized.toLocaleLowerCase();
      if (!normalized || seen.has(key)) return [];
      seen.add(key);
      return [normalized];
    });
  }
  function subjectContext(element) {
    const values = ["alt", "aria-label", "title", "src", "data-src", "poster"].map((name) => element.getAttribute(name) ?? "");
    const link = element.closest("a[href]");
    if (link) values.push(
      link.getAttribute("href") ?? "",
      link.getAttribute("aria-label") ?? "",
      link.getAttribute("title") ?? ""
    );
    const containers = /* @__PURE__ */ new Set([
      element.closest("figure, shreddit-post, [data-testid*='post']"),
      element.closest("article")
    ]);
    for (const container of containers) {
      if (!container) continue;
      values.push(...Array.from(container.querySelectorAll(
        "h1, h2, h3, h4, figcaption, [slot='title'], [slot='post-title']"
      )).map((node) => node.textContent ?? ""));
    }
    return values.join(" ").replace(/\s+/gu, " ");
  }
  function isSubjectCandidate(candidate) {
    return candidate.kind === "image" || candidate.kind === "background-image" || candidate.kind === "native-video" || candidate.kind === "video-iframe";
  }
  function subjectPattern(keyword) {
    const escaped = keyword.replace(/[.*+?^${}()|[\]\\]/gu, "\\$&");
    return new RegExp(`(^|[^\\p{L}\\p{N}])${escaped}($|[^\\p{L}\\p{N}])`, "iu");
  }
  function textMatchesBlockedSubject(text, keywords) {
    return keywords.some((keyword) => subjectPattern(keyword).test(text));
  }

  // src/content/document-observer.ts
  var relevantAttributes = [
    "src",
    "srcset",
    "poster",
    "style",
    "class",
    "alt",
    "title",
    "aria-label"
  ];
  var openShadowEvent = "buof-open-shadow";
  var DocumentObserver = class {
    document;
    createMutationObserver;
    createResizeObserver;
    requestFrame;
    cancelFrame;
    pending = /* @__PURE__ */ new Set();
    observedRoots = /* @__PURE__ */ new WeakSet();
    observedForResize = /* @__PURE__ */ new Set();
    activeLayoutTargets = /* @__PURE__ */ new WeakSet();
    attributeChanges = /* @__PURE__ */ new WeakSet();
    sourceChanges = /* @__PURE__ */ new WeakMap();
    mutationObserver = null;
    resizeObserver = null;
    onCandidates = null;
    onLayoutChange = null;
    layoutDirty = false;
    frame = null;
    constructor(environment = {}) {
      this.document = environment.document ?? document;
      this.createMutationObserver = environment.createMutationObserver ?? ((callback) => new MutationObserver(callback));
      this.createResizeObserver = environment.createResizeObserver ?? ((callback) => new ResizeObserver(callback));
      this.requestFrame = environment.requestAnimationFrame ?? this.document.defaultView.requestAnimationFrame.bind(this.document.defaultView);
      this.cancelFrame = environment.cancelAnimationFrame ?? this.document.defaultView.cancelAnimationFrame.bind(this.document.defaultView);
    }
    start(onCandidates, onLayoutChange) {
      if (this.onCandidates) this.stop();
      this.onCandidates = onCandidates;
      this.onLayoutChange = onLayoutChange ?? null;
      this.resizeObserver = this.createResizeObserver((entries) => {
        for (const entry of entries) this.enqueue(entry.target);
      });
      this.mutationObserver = this.createMutationObserver((records) => {
        for (const record of records) this.processMutation(record);
      });
      this.document.addEventListener(openShadowEvent, this.onOpenShadow);
      this.observeRoot(this.document);
    }
    observeRoot(root) {
      if (this.observedRoots.has(root)) return;
      this.observedRoots.add(root);
      this.mutationObserver?.observe(root, {
        childList: true,
        subtree: true,
        attributes: true,
        characterData: true,
        attributeFilter: [...relevantAttributes]
      });
    }
    scan(root) {
      this.scanTree(root, false);
    }
    trackLayout(element) {
      this.activeLayoutTargets.add(element);
      this.observeResize(element);
    }
    untrackLayout(element) {
      this.activeLayoutTargets.delete(element);
      this.syncResizeObservation(element);
    }
    hadRelevantAttributeChange(element) {
      return this.attributeChanges.has(element);
    }
    sourceChangeCount(element) {
      return this.sourceChanges.get(element) ?? 0;
    }
    stop() {
      this.document.removeEventListener(openShadowEvent, this.onOpenShadow);
      this.mutationObserver?.disconnect();
      this.resizeObserver?.disconnect();
      this.mutationObserver = null;
      this.resizeObserver = null;
      this.onCandidates = null;
      this.onLayoutChange = null;
      this.pending.clear();
      this.observedForResize.clear();
      this.observedRoots = /* @__PURE__ */ new WeakSet();
      this.activeLayoutTargets = /* @__PURE__ */ new WeakSet();
      this.attributeChanges = /* @__PURE__ */ new WeakSet();
      this.sourceChanges = /* @__PURE__ */ new WeakMap();
      this.layoutDirty = false;
      if (this.frame !== null) this.cancelFrame(this.frame);
      this.frame = null;
    }
    onOpenShadow = (event) => {
      const host = event.target;
      if (!(host instanceof HTMLElement) || isExtensionOwned(host) || !host.shadowRoot) return;
      this.observeRoot(host.shadowRoot);
      this.scanTree(host.shadowRoot, false);
    };
    processMutation(record) {
      if (record.type === "characterData") {
        this.layoutDirty = true;
        if (this.frame === null) this.frame = this.requestFrame(() => this.flush());
        return;
      }
      if (record.type === "attributes") {
        if (record.target instanceof Element && !isExtensionOwned(record.target)) {
          this.layoutDirty = true;
          if (record.attributeName === "src") {
            this.sourceChanges.set(
              record.target,
              (this.sourceChanges.get(record.target) ?? 0) + 1
            );
          }
          this.trackTree(record.target, true);
        }
        return;
      }
      let affectsLayout = false;
      for (const node of record.addedNodes) {
        if (!(node instanceof Element)) {
          affectsLayout = true;
          continue;
        }
        if (node instanceof Element && !isExtensionOwned(node)) {
          affectsLayout = true;
          this.trackTree(node, false);
        }
      }
      for (const node of record.removedNodes) {
        if (!(node instanceof Element)) {
          affectsLayout = true;
          continue;
        }
        if (node instanceof Element && !isExtensionOwned(node)) {
          affectsLayout = true;
          this.enqueueTree(node);
          this.unobserveTree(node);
        }
      }
      if (affectsLayout) this.layoutDirty = true;
      if (affectsLayout && this.frame === null) {
        this.frame = this.requestFrame(() => this.flush());
      }
    }
    trackTree(root, attributeChange) {
      this.scanTree(root, attributeChange);
    }
    scanTree(root, attributeChange) {
      if (root instanceof HTMLElement) this.track(root, attributeChange);
      const walker = this.document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
      let node = walker.nextNode();
      while (node) {
        if (node instanceof HTMLElement && !isExtensionOwned(node)) {
          this.track(node, attributeChange);
        }
        node = walker.nextNode();
      }
      const elements = root instanceof Element ? [root, ...Array.from(root.querySelectorAll("*"))] : Array.from(root.querySelectorAll("*"));
      for (const element of elements) {
        if (!(element instanceof HTMLElement) || isExtensionOwned(element)) continue;
        const shadow = element.shadowRoot;
        if (!shadow) continue;
        this.observeRoot(shadow);
        this.scanTree(shadow, attributeChange);
      }
    }
    enqueueTree(root) {
      if (root instanceof HTMLElement) this.enqueue(root);
      const walker = this.document.createTreeWalker(root, NodeFilter.SHOW_ELEMENT);
      let node = walker.nextNode();
      while (node) {
        if (node instanceof HTMLElement) this.enqueue(node);
        node = walker.nextNode();
      }
    }
    unobserveTree(root) {
      this.unobserveResize(root);
      for (const element of root.querySelectorAll("*")) this.unobserveResize(element);
      if (root.shadowRoot) {
        for (const element of root.shadowRoot.querySelectorAll("*")) this.unobserveResize(element);
      }
    }
    track(element, attributeChange = false) {
      this.syncResizeObservation(element);
      if (attributeChange) this.attributeChanges.add(element);
      this.enqueue(element);
    }
    syncResizeObservation(element) {
      const shouldObserve = element.isConnected && (this.activeLayoutTargets.has(element) || isPlausibleResizeCandidate(element));
      if (shouldObserve) this.observeResize(element);
      else this.unobserveResize(element);
    }
    observeResize(element) {
      if (this.observedForResize.has(element)) return;
      this.observedForResize.add(element);
      this.resizeObserver?.observe(element);
    }
    unobserveResize(element) {
      if (!this.observedForResize.delete(element)) return;
      this.resizeObserver?.unobserve?.(element);
    }
    enqueue(element) {
      if (!this.onCandidates) return;
      this.pending.add(element);
      if (this.frame !== null) return;
      this.frame = this.requestFrame(() => this.flush());
    }
    flush() {
      this.frame = null;
      const elements = [...this.pending];
      this.pending.clear();
      if (!this.onCandidates) return;
      try {
        if (elements.length > 0) this.onCandidates(elements);
      } finally {
        for (const element of elements) {
          this.attributeChanges.delete(element);
          this.sourceChanges.delete(element);
        }
        if (this.layoutDirty) {
          this.layoutDirty = false;
          this.onLayoutChange?.();
        }
      }
    }
  };
  function isPlausibleResizeCandidate(element) {
    if (element instanceof HTMLImageElement || element instanceof HTMLVideoElement || element instanceof HTMLIFrameElement || element instanceof HTMLInputElement && element.type.toLowerCase() === "image") {
      return true;
    }
    if (!(element instanceof HTMLElement)) return false;
    const style = element.getAttribute("style") ?? "";
    return /background(?:-image)?\s*:/iu.test(style) || (element.id !== "" || element.classList.length > 0) && !element.textContent?.trim();
  }
  function isExtensionOwned(element) {
    return element.hasAttribute("data-buof-root") || element.closest("[data-buof-root]") !== null;
  }

  // src/content/content-controller.ts
  var ContentController = class {
    document;
    observer;
    renderer;
    nativeVideo;
    providerFrames;
    classify;
    describe;
    development;
    logDiagnostic;
    setDescriptionsVisible;
    byElement = /* @__PURE__ */ new WeakMap();
    records = /* @__PURE__ */ new Set();
    origin = null;
    descriptionsVisible = true;
    blockedSubjects = parseBlockedSubjects(null);
    started = false;
    observing = false;
    constructor(dependencies = {}) {
      this.document = dependencies.document ?? document;
      this.observer = dependencies.observer ?? new DocumentObserver({ document: this.document });
      this.renderer = dependencies.renderer ?? new ProtectionRenderer({
        document: this.document,
        window: this.document.defaultView ?? window
      });
      this.nativeVideo = dependencies.nativeVideo ?? new NativeVideoController();
      this.providerFrames = dependencies.providerFrames ?? new ProviderFrameController();
      const view = this.document.defaultView ?? window;
      this.classify = dependencies.classify ?? ((element) => classifyElement(element, {
        box: (target) => target.getBoundingClientRect(),
        style: (target) => view.getComputedStyle(target)
      }));
      this.describe = dependencies.resolveDescription ?? resolveDescription;
      this.development = dependencies.development ?? isDevelopmentRuntime();
      this.logDiagnostic = dependencies.logDiagnostic ?? ((tagName, message) => console.warn(`Big Ugly Orange Face: ${tagName}: ${message}`));
      this.setDescriptionsVisible = dependencies.setDescriptionsVisible ?? (() => void 0);
    }
    start(context) {
      if (this.started) this.stop();
      this.started = true;
      this.origin = context.origin;
      this.descriptionsVisible = context.descriptionsVisible ?? false;
      this.blockedSubjects = parseBlockedSubjects(context.blockedSubjects);
      this.startObservation();
    }
    applyBlockedSubjects(config) {
      this.blockedSubjects = parseBlockedSubjects(config);
      if (this.started) this.reconcileProtection();
    }
    stop(options = {}) {
      this.stopObservation();
      this.clearProtection(options.restoreMedia ?? true);
      if (options.restoreMedia === false) this.providerFrames.dispose?.();
      this.origin = null;
      this.started = false;
    }
    startObservation() {
      if (this.observing) return;
      this.observing = true;
      this.observer.start(
        (elements) => {
          for (const element of elements) this.processCandidate(element);
        },
        () => {
          for (const record of this.records) record.handle.update();
        }
      );
      this.observer.scan(this.document);
    }
    stopObservation() {
      if (!this.observing) return;
      this.observer.stop();
      this.observing = false;
    }
    processCandidate(element) {
      let detachedCandidate = null;
      try {
        const existing = this.byElement.get(element);
        if (existing) {
          if (!element.isConnected) {
            this.detachRecord(existing, true);
            return;
          }
          if (!this.observer.hadRelevantAttributeChange?.(element)) {
            existing.handle.update();
            return;
          }
          if (existing.handle.isRevealed() && existing.candidate.kind !== "video-iframe") {
            existing.handle.update();
            return;
          }
          if (existing.candidate.kind === "native-video") {
            this.enforceProtection(existing.candidate);
            existing.handle.update();
            return;
          }
          if (existing.candidate.kind === "video-iframe" && element instanceof HTMLIFrameElement) {
            const currentSource = element.getAttribute("src");
            if (currentSource === existing.expectedProviderSource) {
              delete existing.expectedProviderSource;
              existing.handle.update();
              return;
            }
            this.detachRecord(existing, false);
            if (this.providerFrames.forget) this.providerFrames.forget(element);
            else void this.providerFrames.restore(element);
            replaceSource(element, currentSource);
          } else {
            this.detachRecord(existing, false);
            detachedCandidate = existing.candidate;
            this.enforceProtection(existing.candidate);
          }
        }
        if (!element.isConnected) return;
        const candidate = this.classify(element);
        if (candidate && candidateMatchesBlockedSubject(candidate, this.blockedSubjects)) {
          this.createProtection(candidate);
          return;
        }
        if (detachedCandidate) this.restoreMedia(detachedCandidate);
        if (isSupportedVideoFrame(element)) {
          void this.providerFrames.trust?.(
            element,
            this.observer.sourceChangeCount?.(element) ?? 0
          );
        }
      } catch {
        if (detachedCandidate) this.restoreMedia(detachedCandidate);
        this.reportCandidateFailure(element);
      }
    }
    createProtection(candidate) {
      if (isVisualCandidate(candidate) && this.hasOverlappingVideoRecord(candidate)) return;
      if (isVideoCandidate(candidate)) this.removeOverlappingVisualRecords(candidate);
      let prepared = false;
      try {
        const expectedProviderSource = this.prepareMedia(candidate);
        prepared = true;
        let record;
        const handle = this.renderer.protect(candidate, {
          description: this.describe(candidate),
          onReveal: () => {
            void this.releaseRecord(record).catch(() => {
              record.handle.reprotect();
              this.reportProviderFailure(candidate.element);
            });
          },
          onToggleDescriptions: () => this.toggleDescriptions(),
          descriptionsVisible: this.descriptionsVisible,
          onReprotect: () => this.enforceRecord(record)
        });
        record = { candidate, handle };
        if (expectedProviderSource !== void 0) {
          record.expectedProviderSource = expectedProviderSource;
        }
        this.byElement.set(candidate.element, record);
        this.records.add(record);
        this.observer.trackLayout?.(candidate.element);
      } catch (error) {
        if (prepared) this.restoreMedia(candidate);
        throw error;
      }
    }
    hasOverlappingVideoRecord(candidate) {
      for (const record of this.records) {
        if (isVideoCandidate(record.candidate) && sharesOverlappingMediaStack(candidate.element, record.candidate.element)) {
          return true;
        }
      }
      return false;
    }
    removeOverlappingVisualRecords(candidate) {
      for (const record of [...this.records]) {
        if (isVisualCandidate(record.candidate) && sharesOverlappingMediaStack(record.candidate.element, candidate.element)) {
          this.detachRecord(record, true);
        }
      }
    }
    toggleDescriptions() {
      this.descriptionsVisible = !this.descriptionsVisible;
      if (this.origin) {
        void Promise.resolve(this.setDescriptionsVisible(this.origin, this.descriptionsVisible)).catch(() => void 0);
      }
      for (const record of this.records) {
        record.handle.setDescriptionVisible(this.descriptionsVisible);
      }
    }
    prepareMedia(candidate) {
      if (candidate.kind === "native-video") {
        if (!(candidate.element instanceof HTMLVideoElement)) {
          throw new TypeError("Invalid native video candidate");
        }
        this.nativeVideo.secure(candidate.element);
        return void 0;
      }
      if (candidate.kind === "video-iframe") {
        if (!(candidate.element instanceof HTMLIFrameElement)) {
          throw new TypeError("Invalid provider frame candidate");
        }
        this.providerFrames.gate(candidate.element);
        return candidate.element.getAttribute("src");
      }
      return void 0;
    }
    async releaseRecord(record) {
      const { candidate } = record;
      if (candidate.kind === "native-video" && candidate.element instanceof HTMLVideoElement) {
        this.nativeVideo.release(candidate.element);
      } else if (candidate.kind === "video-iframe" && candidate.element instanceof HTMLIFrameElement) {
        await this.providerFrames.release(candidate.element);
        record.expectedProviderSource = candidate.element.getAttribute("src");
      }
    }
    enforceRecord(record) {
      this.enforceProtection(record.candidate);
      if (record.candidate.kind === "video-iframe" && record.candidate.element instanceof HTMLIFrameElement) {
        record.expectedProviderSource = record.candidate.element.getAttribute("src");
      }
    }
    enforceProtection(candidate) {
      if (candidate.kind === "native-video" && candidate.element instanceof HTMLVideoElement) {
        this.nativeVideo.reprotect(candidate.element);
      } else if (candidate.kind === "video-iframe" && candidate.element instanceof HTMLIFrameElement) {
        this.providerFrames.regate(candidate.element);
      }
    }
    restoreMedia(candidate) {
      if (candidate.kind === "native-video" && candidate.element instanceof HTMLVideoElement) {
        this.nativeVideo.restore(candidate.element);
      } else if (candidate.kind === "video-iframe" && candidate.element instanceof HTMLIFrameElement) {
        this.providerFrames.restore(candidate.element);
      }
    }
    detachRecord(record, restore) {
      record.handle.remove();
      this.records.delete(record);
      this.byElement.delete(record.candidate.element);
      this.observer.untrackLayout?.(record.candidate.element);
      if (restore) this.restoreMedia(record.candidate);
    }
    clearProtection(restore = true) {
      for (const record of [...this.records]) {
        this.detachRecord(record, restore);
        if (!restore && record.candidate.kind === "video-iframe" && record.candidate.element instanceof HTMLIFrameElement) {
          this.providerFrames.forget?.(record.candidate.element);
        }
      }
    }
    reconcileProtection() {
      for (const record of [...this.records]) {
        if (!record.candidate.element.isConnected || !candidateMatchesBlockedSubject(record.candidate, this.blockedSubjects)) {
          this.detachRecord(record, true);
        }
      }
      this.observer.scan(this.document);
    }
    reportCandidateFailure(element) {
      if (!this.development) return;
      this.logDiagnostic(element.tagName, "candidate processing failed");
    }
    reportProviderFailure(element) {
      if (!this.development) return;
      this.logDiagnostic(element.tagName, "provider allow rule failed");
    }
  };
  function isDevelopmentRuntime() {
    return false;
  }
  function replaceSource(frame, source) {
    if (source === null) frame.removeAttribute("src");
    else frame.setAttribute("src", source);
  }
  function isVisualCandidate(candidate) {
    return candidate.kind === "image" || candidate.kind === "background-image";
  }
  function isVideoCandidate(candidate) {
    return candidate.kind === "native-video" || candidate.kind === "video-iframe";
  }
  function sharesOverlappingMediaStack(first, second) {
    if (first.ownerDocument !== second.ownerDocument || !sharesNearbyAncestor(first, second)) {
      return false;
    }
    const firstBox = first.getBoundingClientRect();
    const secondBox = second.getBoundingClientRect();
    const smallerArea = Math.min(firstBox.width * firstBox.height, secondBox.width * secondBox.height);
    const largerArea = Math.max(firstBox.width * firstBox.height, secondBox.width * secondBox.height);
    if (smallerArea <= 0 || smallerArea / largerArea < 0.5) return false;
    const intersectionWidth = Math.max(
      0,
      Math.min(firstBox.right, secondBox.right) - Math.max(firstBox.left, secondBox.left)
    );
    const intersectionHeight = Math.max(
      0,
      Math.min(firstBox.bottom, secondBox.bottom) - Math.max(firstBox.top, secondBox.top)
    );
    return intersectionWidth * intersectionHeight / smallerArea >= 0.8;
  }
  function sharesNearbyAncestor(first, second) {
    const firstAncestors = /* @__PURE__ */ new Set();
    let current = first;
    for (let depth = 0; current && current !== first.ownerDocument.body && depth < 8; depth += 1) {
      firstAncestors.add(current);
      current = current.parentElement;
    }
    current = second;
    for (let depth = 0; current && current !== second.ownerDocument.body && depth < 8; depth += 1) {
      if (firstAncestors.has(current)) return true;
      current = current.parentElement;
    }
    return false;
  }

  // src/shared/description-preferences.ts
  function descriptionsKey(origin) {
    return `site-descriptions:${origin}`;
  }
  var DescriptionPreferencesStore = class {
    constructor(area) {
      this.area = area;
    }
    area;
    async get(origin) {
      const key = descriptionsKey(origin);
      return (await this.area.get(key))[key] === true;
    }
    async set(origin, visible) {
      await this.area.set({ [descriptionsKey(origin)]: visible });
    }
  };

  // src/content/index.ts
  async function bootstrapContentScript(dependencies = productionDependencies()) {
    const page = parseUrl(dependencies.href);
    if (!page || !isEligibleDocument(page, dependencies)) return;
    if (dependencies.isChildFrame && isSupportedProviderDocument(page)) return;
    const controller = dependencies.createController();
    let stopWatching = null;
    let currentBlockedSubjects = null;
    let started = false;
    let disposed = false;
    dependencies.addPageHideListener(() => {
      disposed = true;
      stopWatching?.();
      controller.stop({ restoreMedia: false });
    });
    stopWatching = dependencies.watchBlockedSubjects((config) => {
      currentBlockedSubjects = config;
      if (started) controller.applyBlockedSubjects(config);
    });
    const origin = fallbackOrigin(page, dependencies);
    const [descriptionsVisible, storedSubjects] = await Promise.all([
      dependencies.getDescriptionsVisible(origin).catch(() => false),
      dependencies.getBlockedSubjects().catch(() => ({ enabled: false, keywords: [] }))
    ]);
    if (disposed) return;
    controller.start({
      origin,
      descriptionsVisible,
      blockedSubjects: currentBlockedSubjects ?? storedSubjects
    });
    started = true;
  }
  function productionDependencies() {
    const descriptions = new DescriptionPreferencesStore(chrome.storage.local);
    const blockedSubjects = new BlockedSubjectsStore(chrome.storage.local, chrome.storage.onChanged);
    return {
      href: window.location.href,
      isChildFrame: window !== window.top,
      parentLocation: () => {
        try {
          return {
            protocol: window.parent.location.protocol,
            origin: window.parent.location.origin
          };
        } catch {
          return null;
        }
      },
      createController: () => new ContentController({
        setDescriptionsVisible: (origin, visible) => descriptions.set(origin, visible)
      }),
      getDescriptionsVisible: (origin) => descriptions.get(origin),
      getBlockedSubjects: () => blockedSubjects.get(),
      watchBlockedSubjects: (listener) => blockedSubjects.watch(listener),
      addPageHideListener: (listener) => {
        window.addEventListener("pagehide", listener, { once: true });
      }
    };
  }
  function parseUrl(href) {
    try {
      return new URL(href);
    } catch {
      return null;
    }
  }
  function isEligibleDocument(page, dependencies) {
    if (page.protocol === "http:" || page.protocol === "https:") return true;
    if (page.href !== "about:blank" || !dependencies.isChildFrame) return false;
    const parent = dependencies.parentLocation();
    return parent?.protocol === "http:" || parent?.protocol === "https:";
  }
  function isSupportedProviderDocument(page) {
    if (page.protocol !== "https:") return false;
    if (page.hostname === "www.youtube.com" || page.hostname === "www.youtube-nocookie.com") {
      return /^\/embed\/[^/]+$/.test(page.pathname);
    }
    return page.hostname === "player.vimeo.com" && /^\/video\/[^/]+$/.test(page.pathname);
  }
  function fallbackOrigin(page, dependencies) {
    if (page.protocol === "http:" || page.protocol === "https:") return page.origin;
    return dependencies.parentLocation()?.origin ?? "null";
  }
  if (typeof chrome !== "undefined" && typeof chrome.runtime?.sendMessage === "function") {
    void bootstrapContentScript();
  }
})();
//# sourceMappingURL=content.js.map
